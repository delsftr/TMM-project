<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Social Media</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" />

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/styles.css" />

    <!-- ICONS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
  </head>

  <body>
    <!--NAVBAR-->
    <nav class="side-nav nav-container">
      <div class="container-fluid">
        <a class="navbar-brand" href="#homepage">
          <img src="assets/img/LOGO TRICOM-04 1.png" alt="Bootstrap" width="80" height="60" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="nav-icon text-center" id="navbarIcon">
        <a href="/"><i class="bi bi-arrow-left" style="font-size: 30px; color: #000000"></i></a>
      </div>
    </nav>
    <!-- NAVBAR END-->

    <!-- SOCIAL MEDIA PAGE -->
    <section class="container-fluid social-media-page" id="social-media-page">
      <p class="title fs-1 fw-bold" style="color: #0659A7">Video Production</p>
      <div class="row mb-5">
        <div class="col">
          <div class="vision">
            <h5 class="card-title col-8 lh-base fw-semibold">Information and Portofolio</h5>
            <br />
            <p class="card-text col-11 lh-base fw-light">See how we have positively impacted our clients by our work.</p>
          </div>
        </div>
      </div>

      <div class="row mb-5">
        <div class="col-md-4">
          <img src="assets/img/jack-nicklaus.png" class="img-fluid" alt="..." />
        </div>
        <div class="col-md-8">
          <div class="jack-nicklaus">
            <h5 class="card-title col-8 lh-base fw-semibold">Jack Nicklaus</h5>
            <br />
            <p class="card-text col-11 lh-base fw-light">
              Jack Nicklaus Indonesia, the brand that inspired by the golf sports culture and lifestyle. Jack Nicklaus offer a variety of casual and sporty menswear such as polo shirts, smart casual shirts, pants, bermuda and more.
            </p>
          </div>
        </div>
      </div>

      <div class="row mb-5">
        <div class="col-md-4">
          <img src="assets/img/jobb.png" class="img-fluid" alt="..." />
        </div>
        <div class="col-md-8">
          <div class="jobb">
            <h5 class="card-title col-8 lh-base fw-semibold">JOBB</h5>
            <br />
            <p class="card-text col-11 lh-base fw-light">
              JOBB started its journey as brand in 1994, JOBB has expanded into a today’s Fashion lead brand. For those of you who is looking for inspiration about the latest clothing or bottoms for your daily activities, then you must have
              JOBB.
            </p>
          </div>
        </div>
      </div>

      <div class="row mb-5">
        <div class="col-md-4">
          <img src="assets/img/chitose.png" class="img-fluid" alt="..." />
        </div>
        <div class="col-md-8">
          <div class="chitose">
            <h5 class="card-title col-8 lh-base fw-semibold">Chitose</h5>
            <br />
            <p class="card-text col-11 lh-base fw-light">Chitose is a high-tech chair brand that guarantees its users' comfort.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- SOCIAL MEDIA PAGE END -->

    <!-- CONTACT -->
    <section class="container-fluid contact" id="contact" style="background-color: #d9d9d942">
      <p class="title fs-1 fw-bold" style="color: #0659a7">Let’s discuss your project!</p>
      <div class="row g-0">
        <div class="col-md-7">
          <div class="contact-icon">
            <p class="whatsapp"><i class="bi bi-whatsapp" style="font-size: 25px; color: #0659a7"></i> 123 123 123</p>
            <p class="email"><i class="bi bi-envelope" style="font-size: 25px; color: #0659a7"></i> mail123@gmail.com</p>
            <p class="address">
              <i class="bi bi-geo-alt" style="font-size: 25px; color: #0659a7"></i> Trisula Center Jalan Lingkar Luar Barat Blok A - B 1, RT.14/RW.14, Rw. Buaya, Kecamatan Cengkareng, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11740
            </p>
          </div>
        </div>
        <div class="col-md-4">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.666879455042!2d106.72665651476889!3d-6.175331995529216!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f78167bb60d5%3A0x390ec47a1212cbca!2sTrisula%20Center!5e0!3m2!1sid!2sid!4v1683168836580!5m2!1sid!2sid"
            width="400"
            height="200"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </div>
    </section>
    <!-- CONTACT END -->

    <!-- FOOTER -->
    <footer class="footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-9">
            <p class="text-white">
              &copy;
              <script>
                document.write(new Date().getFullYear());
              </script>
              Tricom
            </p>
          </div>
          <div class="col-md-1">
            <a href="https://www.instagram.com"><i class="bi bi-instagram" style="font-size: 25px; color: #ffffff"></i></a>
            <a href="https://www.youtube.com"><i class="bi bi-youtube" style="font-size: 25px; color: #ffffff"></i></a>
          </div>
        </div>
      </div>
    </footer>
    <!-- FOOTER END -->
  </body>
</html>